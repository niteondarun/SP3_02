﻿namespace SP3_02
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Square_Click = new System.Windows.Forms.Button();
            this.btn_Rectangle_Click = new System.Windows.Forms.Button();
            this.btn_Circle_Click = new System.Windows.Forms.Button();
            this.btn_Triangle_Click = new System.Windows.Forms.Button();
            this.btn_Diamond_Click = new System.Windows.Forms.Button();
            this.btn_Trapezoid_Click = new System.Windows.Forms.Button();
            this.panel_Background = new System.Windows.Forms.Panel();
            this.btn_BackgroundColor_Click = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Title = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btn_PaintColor_Click = new System.Windows.Forms.Button();
            this.TxtBox_SizeInput_Type = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel_Background.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Square_Click
            // 
            this.btn_Square_Click.BackColor = System.Drawing.SystemColors.Window;
            this.btn_Square_Click.Location = new System.Drawing.Point(24, 582);
            this.btn_Square_Click.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Square_Click.Name = "btn_Square_Click";
            this.btn_Square_Click.Size = new System.Drawing.Size(88, 46);
            this.btn_Square_Click.TabIndex = 0;
            this.btn_Square_Click.Text = "Square";
            this.btn_Square_Click.UseVisualStyleBackColor = false;
            this.btn_Square_Click.Click += new System.EventHandler(this.btn_Square_Click_Click);
            // 
            // btn_Rectangle_Click
            // 
            this.btn_Rectangle_Click.BackColor = System.Drawing.SystemColors.Window;
            this.btn_Rectangle_Click.Location = new System.Drawing.Point(24, 631);
            this.btn_Rectangle_Click.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Rectangle_Click.Name = "btn_Rectangle_Click";
            this.btn_Rectangle_Click.Size = new System.Drawing.Size(91, 46);
            this.btn_Rectangle_Click.TabIndex = 1;
            this.btn_Rectangle_Click.Text = "Rectangle";
            this.btn_Rectangle_Click.UseVisualStyleBackColor = false;
            // 
            // btn_Circle_Click
            // 
            this.btn_Circle_Click.BackColor = System.Drawing.SystemColors.Window;
            this.btn_Circle_Click.Location = new System.Drawing.Point(27, 681);
            this.btn_Circle_Click.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Circle_Click.Name = "btn_Circle_Click";
            this.btn_Circle_Click.Size = new System.Drawing.Size(88, 46);
            this.btn_Circle_Click.TabIndex = 2;
            this.btn_Circle_Click.Text = "Circle";
            this.btn_Circle_Click.UseVisualStyleBackColor = false;
            // 
            // btn_Triangle_Click
            // 
            this.btn_Triangle_Click.BackColor = System.Drawing.SystemColors.Window;
            this.btn_Triangle_Click.Location = new System.Drawing.Point(149, 582);
            this.btn_Triangle_Click.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Triangle_Click.Name = "btn_Triangle_Click";
            this.btn_Triangle_Click.Size = new System.Drawing.Size(88, 46);
            this.btn_Triangle_Click.TabIndex = 3;
            this.btn_Triangle_Click.Text = "Triangle";
            this.btn_Triangle_Click.UseVisualStyleBackColor = false;
            this.btn_Triangle_Click.Click += new System.EventHandler(this.btn_Triangle_Click_Click);
            // 
            // btn_Diamond_Click
            // 
            this.btn_Diamond_Click.BackColor = System.Drawing.SystemColors.Window;
            this.btn_Diamond_Click.Location = new System.Drawing.Point(149, 681);
            this.btn_Diamond_Click.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Diamond_Click.Name = "btn_Diamond_Click";
            this.btn_Diamond_Click.Size = new System.Drawing.Size(88, 46);
            this.btn_Diamond_Click.TabIndex = 4;
            this.btn_Diamond_Click.Text = "Diamond";
            this.btn_Diamond_Click.UseVisualStyleBackColor = false;
            // 
            // btn_Trapezoid_Click
            // 
            this.btn_Trapezoid_Click.BackColor = System.Drawing.SystemColors.Window;
            this.btn_Trapezoid_Click.Location = new System.Drawing.Point(149, 631);
            this.btn_Trapezoid_Click.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Trapezoid_Click.Name = "btn_Trapezoid_Click";
            this.btn_Trapezoid_Click.Size = new System.Drawing.Size(88, 46);
            this.btn_Trapezoid_Click.TabIndex = 5;
            this.btn_Trapezoid_Click.Text = "Circle";
            this.btn_Trapezoid_Click.UseVisualStyleBackColor = false;
            this.btn_Trapezoid_Click.Click += new System.EventHandler(this.btn_Trapezoid_Click_Click);
            // 
            // panel_Background
            // 
            this.panel_Background.BackColor = System.Drawing.Color.LightCoral;
            this.panel_Background.Controls.Add(this.btn_BackgroundColor_Click);
            this.panel_Background.Controls.Add(this.label6);
            this.panel_Background.Controls.Add(this.textBox2);
            this.panel_Background.Controls.Add(this.label5);
            this.panel_Background.Controls.Add(this.Title);
            this.panel_Background.Controls.Add(this.textBox1);
            this.panel_Background.Controls.Add(this.btn_PaintColor_Click);
            this.panel_Background.Controls.Add(this.TxtBox_SizeInput_Type);
            this.panel_Background.Controls.Add(this.label4);
            this.panel_Background.Controls.Add(this.label1);
            this.panel_Background.Controls.Add(this.label3);
            this.panel_Background.Controls.Add(this.btn_Diamond_Click);
            this.panel_Background.Controls.Add(this.label2);
            this.panel_Background.Controls.Add(this.btn_Trapezoid_Click);
            this.panel_Background.Controls.Add(this.btn_Square_Click);
            this.panel_Background.Controls.Add(this.btn_Rectangle_Click);
            this.panel_Background.Controls.Add(this.btn_Triangle_Click);
            this.panel_Background.Controls.Add(this.btn_Circle_Click);
            this.panel_Background.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_Background.Location = new System.Drawing.Point(0, 0);
            this.panel_Background.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_Background.Name = "panel_Background";
            this.panel_Background.Size = new System.Drawing.Size(248, 679);
            this.panel_Background.TabIndex = 6;
            // 
            // btn_BackgroundColor_Click
            // 
            this.btn_BackgroundColor_Click.BackColor = System.Drawing.SystemColors.Window;
            this.btn_BackgroundColor_Click.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_BackgroundColor_Click.Location = new System.Drawing.Point(117, 480);
            this.btn_BackgroundColor_Click.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_BackgroundColor_Click.Name = "btn_BackgroundColor_Click";
            this.btn_BackgroundColor_Click.Size = new System.Drawing.Size(101, 46);
            this.btn_BackgroundColor_Click.TabIndex = 8;
            this.btn_BackgroundColor_Click.Text = "Background";
            this.btn_BackgroundColor_Click.UseVisualStyleBackColor = false;
            this.btn_BackgroundColor_Click.Click += new System.EventHandler(this.btn_BackgroundColor_Click_Click);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(27, 229);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 36);
            this.label6.TabIndex = 10;
            this.label6.Text = "Y :";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(117, 233);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(103, 22);
            this.textBox2.TabIndex = 8;
            this.textBox2.Text = "0";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(27, 194);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 36);
            this.label5.TabIndex = 9;
            this.label5.Text = "X :";
            // 
            // Title
            // 
            this.Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title.Location = new System.Drawing.Point(3, 6);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(256, 106);
            this.Title.TabIndex = 7;
            this.Title.Text = "Bob Ross\'s Paint Show";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(117, 198);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(103, 22);
            this.textBox1.TabIndex = 7;
            this.textBox1.Text = "0";
            // 
            // btn_PaintColor_Click
            // 
            this.btn_PaintColor_Click.BackColor = System.Drawing.SystemColors.Window;
            this.btn_PaintColor_Click.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_PaintColor_Click.Location = new System.Drawing.Point(117, 415);
            this.btn_PaintColor_Click.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_PaintColor_Click.Name = "btn_PaintColor_Click";
            this.btn_PaintColor_Click.Size = new System.Drawing.Size(101, 46);
            this.btn_PaintColor_Click.TabIndex = 7;
            this.btn_PaintColor_Click.Text = "Paint";
            this.btn_PaintColor_Click.UseVisualStyleBackColor = false;
            this.btn_PaintColor_Click.Click += new System.EventHandler(this.btn_PaintColor_Click_Click);
            // 
            // TxtBox_SizeInput_Type
            // 
            this.TxtBox_SizeInput_Type.Location = new System.Drawing.Point(117, 332);
            this.TxtBox_SizeInput_Type.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TxtBox_SizeInput_Type.Name = "TxtBox_SizeInput_Type";
            this.TxtBox_SizeInput_Type.Size = new System.Drawing.Size(96, 22);
            this.TxtBox_SizeInput_Type.TabIndex = 7;
            this.TxtBox_SizeInput_Type.Text = "0";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 36);
            this.label4.TabIndex = 10;
            this.label4.Text = "Postion";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 553);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 27);
            this.label1.TabIndex = 7;
            this.label1.Text = "Shapes";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 295);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 36);
            this.label3.TabIndex = 9;
            this.label3.Text = "Size";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 379);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 36);
            this.label2.TabIndex = 8;
            this.label2.Text = "Colors";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Info;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(248, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(735, 679);
            this.panel2.TabIndex = 7;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(983, 679);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel_Background);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_Background.ResumeLayout(false);
            this.panel_Background.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Square_Click;
        private System.Windows.Forms.Button btn_Rectangle_Click;
        private System.Windows.Forms.Button btn_Circle_Click;
        private System.Windows.Forms.Button btn_Triangle_Click;
        private System.Windows.Forms.Button btn_Diamond_Click;
        private System.Windows.Forms.Button btn_Trapezoid_Click;
        private System.Windows.Forms.Panel panel_Background;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btn_PaintColor_Click;
        private System.Windows.Forms.TextBox TxtBox_SizeInput_Type;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_BackgroundColor_Click;
    }
}

