# SP3_02
Initial Commit Test/Learning

I think you have to click the "clone" or "download" button and then in VS on the bottom right of your screen it says master.
Click on master and create a new branch with your name

make whatever changes you want to and in the Team Explorer window if you click on the home icon
there is a button called "changes" that you can click on and then to upload your changes you type in a description of the 
changes made and then click "Commit All" and then sync

Might have gotten some of that wrong but I am still super confused, I think that will work though.  I had download another thing
called Git, apparently that is different than GitHub and you need both
